
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dianifelse;

/**
 *
 * @author DNS
 */
public class Dianifelse {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int x= 35;
        int y = 22;
        int waktu = 30;
        int time = 15;
        int Time = 20;
        
        if (35>22){
            System.out.println("35 Lebih besar daripada 22");
        }
        
        if (x>y){
            System.out.println("X lebih besar daripada Y");
        }
        
        if (waktu<22){
            System.out.println("Good Day");
        }else{
            System.out.println("Good Evening");
        }
        
        if (time<15){
            System.out.println("Good Morning");
        }else if (time<20){
            System.out.println("Good Day");
        }else{System.out.println("Good Evening");
                }
        
        
        String result = (Time<22)? "Good Day":"Good Evening";
        System.out.println(result);
        
        
    }
    
}
